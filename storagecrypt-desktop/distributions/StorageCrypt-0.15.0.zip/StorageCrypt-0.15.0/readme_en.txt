* install java 7 and the "Java Cryptography Extension (JCE) Unlimited Strength Jurisdiction Policy" extension

** On ubuntu :
sudo add-apt-repository ppa:webupd8team/java
sudo apt-get update
sudo apt-get install oracle-java7-installer
sudo apt-get install oracle-java7-unlimited-jce-policy

** On Windows :
- Download and install Java 7
- Download and install "Java Cryptography Extension (JCE) Unlimited Strength Jurisdiction Policy" : http://www.oracle.com/technetwork/java/javase/downloads/jce-7-download-432124.html

* extract the StorageCrypt archive
* launch the application :
** on Windows, run StorageCrypt.bat
** on Linux or MacOS, run StorageCrypt.sh

