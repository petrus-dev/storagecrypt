* installer java 7 et l'extension "Java Cryptography Extension (JCE) Unlimited Strength Jurisdiction Policy"

** Sous ubuntu :
sudo add-apt-repository ppa:webupd8team/java
sudo apt-get update
sudo apt-get install oracle-java7-installer
sudo apt-get install oracle-java7-unlimited-jce-policy

** Sous Windows :
- Télécharger et installer Java 7
- Télécharger et installer "Java Cryptography Extension (JCE) Unlimited Strength Jurisdiction Policy" : http://www.oracle.com/technetwork/java/javase/downloads/jce-7-download-432124.html

* extraire l'archive de StorageCrypt
* exécuter l'application :
** sous Windows, exécuter StorageCrypt.bat
** sous Linux ou MacOS, exécuter StorageCrypt.sh

