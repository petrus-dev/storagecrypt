* install java 8 and the "Java Cryptography Extension (JCE) Unlimited Strength Jurisdiction Policy" extension

** On ubuntu :
sudo add-apt-repository ppa:webupd8team/java
sudo apt-get update
sudo apt-get install oracle-java8-installer
sudo apt-get install oracle-java8-unlimited-jce-policy

** On Windows :
- Download and install Java 8
- Download and install "Java Cryptography Extension (JCE) Unlimited Strength Jurisdiction Policy" : http://www.oracle.com/technetwork/java/javase/downloads/jce8-download-2133166.html

* extract the StorageCrypt archive
* launch the application :
** on Windows, run StorageCrypt.bat
** on Linux or MacOS, run StorageCrypt.sh

